import matplotlib.pyplot as plt
import numpy as np
import time
from scipy.interpolate import CubicSpline
import matplotlib as mpl
from PIL import Image
from scipy.ndimage import rotate, shift, gaussian_filter

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['mathtext.fontset'] = 'stix'
mpl.rcParams['axes.unicode_minus'] = False

mpl.rcParams['font.size'] = 28
mpl.rcParams['axes.labelsize'] = 28
mpl.rcParams['axes.titlesize'] = 28
mpl.rcParams['xtick.labelsize'] = 24
mpl.rcParams['ytick.labelsize'] = 24
mpl.rcParams['legend.fontsize'] = 22

# =========================
# Global Setting
# =========================
SEED = 42
np.random.seed(SEED)

max_iter = 1000
eps = 1e-4
converge = 1e-9
safety = 1e-10

# =========================
# Helper functions
# =========================
def normalize_positive(x):
    x = np.maximum(x, 0)
    s = np.sum(x)
    if s < 1e-15:
        return np.ones_like(x) / len(x)
    return x / s

def very_slight_rotation(img2d, angle_deg=1.5):
    out = rotate(img2d, angle=angle_deg, reshape=False, order=1, mode='nearest')
    return np.clip(out, 0, None)

def very_slight_brightness(img2d, factor=1.04):
    out = img2d * factor
    return np.clip(out, 0, None)

def very_slight_smoothing(img2d, sigma=0.6):
    out = gaussian_filter(img2d, sigma=sigma)
    return np.clip(out, 0, None)

def very_slight_shift(img2d, shift_xy=(1.0, -1.0)):
    # shift takes (shift_y, shift_x)
    out = shift(img2d, shift=shift_xy, order=1, mode='nearest')
    return np.clip(out, 0, None)

# =========================
# Import images
# =========================
img_path = r"C:\Users\lenovo\OneDrive\Desktop\涂一辉 机器学习\DBOT\Python算法\image\cheetah_64.png"
img = Image.open(img_path).convert("L")
b1_img = np.array(img, dtype=np.float64)

# random noise image
b2_img = np.random.rand(64, 64)

# Original flattened vectors
b1 = b1_img.reshape(-1)
b2 = b2_img.reshape(-1)

sum1 = np.sum(b1)
sum2 = np.sum(b2)

N = len(b1)  # 4096

# =========================
# Cost matrix
# =========================
grid_size = 64
t = np.linspace(0, grid_size - 1, grid_size)
Y, X = np.meshgrid(t, t)
position = np.vstack((X.reshape(-1), Y.reshape(-1))).T   # shape: (4096, 2)

# squared Euclidean cost matrix
diff = position[:, None, :] - position[None, :, :]
C = np.sum(diff**2, axis=2)

# normalization
C = C.astype(np.float64)
C = C / np.max(C)

K = np.exp(-C / eps)

# =========================
# Main Code: Baseline and DBOT
# =========================
def BaselineBarycenter(b1, b2, lambd):
    N = len(b1)
    b1 = b1 / b1.sum()
    b2 = b2 / b2.sum()
    u1, v1 = np.ones(N), np.ones(N)
    u2, v2 = np.ones(N), np.ones(N)
    a = np.ones(N) / N

    starttime = time.time()
    for _ in range(max_iter):
        v1 = b1 / (K.T @ u1 + safety)
        v2 = b2 / (K.T @ u2 + safety)
        a = (K @ v1) ** lambd * (K @ v2) ** (1 - lambd)
        a = a / a.sum()
        u1 = a / (K @ v1 + safety)
        u2 = a / (K @ v2 + safety)
        if np.sum(np.abs(u1 * (K.T @ v1) - a)) < converge:
            break
    elapse = time.time() - starttime

    P1 = np.outer(u1, v1) * K
    Wab1 = np.sum(C * P1)
    P2 = np.outer(u2, v2) * K
    Wab2 = np.sum(C * P2)
    Distance = lambd * Wab1 + (1 - lambd) * Wab2

    a_image = a.reshape(64, 64)
    return a_image, Distance, elapse


def DBOTBarycenter(b1D, b1U, b2D, b2U, sum1, sum2, lambd):
    N = len(b1D)
    b1D, b1U = b1D / sum1, b1U / sum1
    b2D, b2U = b2D / sum2, b2U / sum2
    u1, v1, q1 = np.ones(N), np.ones(N), np.ones(N)
    u2, v2, q2 = np.ones(N), np.ones(N), np.ones(N)
    a = np.ones(N) / N

    starttime = time.time()
    for _ in range(max_iter):
        uK1 = u1 @ K
        uK2 = u2 @ K

        q1 = np.maximum(b1D / (uK1 * v1 + safety), np.ones_like(v1))
        v1 = np.minimum(b1U / (uK1 * q1 + safety), np.ones_like(v1))

        q2 = np.maximum(b2D / (uK2 * v2 + safety), np.ones_like(v2))
        v2 = np.minimum(b2U / (uK2 * q2 + safety), np.ones_like(v2))

        a = (K @ (v1 * q1)) ** lambd * (K @ (v2 * q2)) ** (1 - lambd)
        a = a / a.sum()

        u1 = a / (K @ (v1 * q1) + safety)
        u2 = a / (K @ (v2 * q2) + safety)

        if np.sum(np.abs(u1 * (K.T @ (v1 * q1)) - a)) < converge:
            break

    elapse = time.time() - starttime

    P1 = np.outer(u1, v1 * q1) * K
    Wab1 = np.sum(C * P1)
    P2 = np.outer(u2, v2 * q2) * K
    Wab2 = np.sum(C * P2)
    Distance = lambd * Wab1 + (1 - lambd) * Wab2

    a_image = a.reshape(64, 64)
    return a_image, Distance, elapse

# =========================
# CV Transformations
# =========================
# Cheetah:
#   T1 = very slight rotation
#   T2 = very slight brightness adjustment
cheetah_t1 = very_slight_rotation(b1_img, angle_deg=1.5)
cheetah_t2 = very_slight_brightness(b1_img, factor=1.04)

# Noise:
#   T1 = very slight smoothing
#   T2 = very slight shift
noise_t1 = very_slight_smoothing(b2_img, sigma=0.6)
noise_t2 = very_slight_shift(b2_img, shift_xy=(1.0, -1.0))

# Flatten
cheetah_t1 = cheetah_t1.reshape(-1)
cheetah_t2 = cheetah_t2.reshape(-1)
noise_t1 = noise_t1.reshape(-1)
noise_t2 = noise_t2.reshape(-1)

# Optional normalization of transformed candidates before min/max
cheetah_t1 = normalize_positive(cheetah_t1)
cheetah_t2 = normalize_positive(cheetah_t2)
noise_t1 = normalize_positive(noise_t1)
noise_t2 = normalize_positive(noise_t2)

# Lower / Upper bounds by elementwise min/max
b1d = np.minimum(cheetah_t1, cheetah_t2)
b1u = np.maximum(cheetah_t1, cheetah_t2)
b2d = np.minimum(noise_t1, noise_t2)
b2u = np.maximum(noise_t1, noise_t2)

# sums for DBOT normalization
sum1_bound = np.sum(b1_img)   # keep original style if you want
sum2_bound = np.sum(b2_img)

# 更稳妥一点，也可以这样：
sum1_bound = 1.0
sum2_bound = 1.0

# =========================
# Main Experiment
# =========================
lambd_list = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]

title_text = "实验：从噪声到豹子的平滑过渡"
print(title_text.center(130))
print("=" * 130)

baseline_results = []
dbot_results = []
baseline_times = []
dbot_times = []
baseline_distances = []
dbot_distances = []

for lambd in lambd_list:
    a_base, d_base, t_base = BaselineBarycenter(b1, b2, lambd)
    a_dbot, d_dbot, t_dbot = DBOTBarycenter(b1d, b1u, b2d, b2u, sum1_bound, sum2_bound, lambd)

    baseline_results.append(a_base)
    dbot_results.append(a_dbot)
    baseline_times.append(t_base)
    dbot_times.append(t_dbot)
    baseline_distances.append(d_base)
    dbot_distances.append(d_dbot)

    print(
        f"权重λ：{lambd:.1f} | Baseline时间：{t_base:.6f}s | DBOT时间：{t_dbot:.6f}s | "
        f"Baseline Distance：{d_base:.6f} | DBOT Distance：{d_dbot:.6f}"
    )

print("=" * 130)

# =========================
# Visualization 0:
# Upper Bound and Lower Bound under CV Transformation
# =========================
fig0, axes0 = plt.subplots(2, 2, figsize=(10, 10))
fig0.suptitle("Upper Bound and Lower Bound under CV Transformation", y=0.98, fontsize=26)

# Row 1: Cheetah
axes0[0, 0].imshow(b1d.reshape(64, 64), cmap='gray')
axes0[0, 0].set_title("Lower Bound", pad=10, fontsize=22)
axes0[0, 0].axis("off")

axes0[0, 1].imshow(b1u.reshape(64, 64), cmap='gray')
axes0[0, 1].set_title("Upper Bound", pad=10, fontsize=22)
axes0[0, 1].axis("off")

# Row 2: Noise
axes0[1, 0].imshow(b2d.reshape(64, 64), cmap='gray')
axes0[1, 0].set_title("Lower Bound", pad=10, fontsize=22)
axes0[1, 0].axis("off")

axes0[1, 1].imshow(b2u.reshape(64, 64), cmap='gray')
axes0[1, 1].set_title("Upper Bound", pad=10, fontsize=22)
axes0[1, 1].axis("off")

fig0.text(0.04, 0.72, "Cheetah", rotation=90, va='center', ha='center', fontsize=22)
fig0.text(0.04, 0.28, "Noise", rotation=90, va='center', ha='center', fontsize=22)

plt.tight_layout(rect=[0.06, 0.03, 1, 0.94])
plt.show()

# =========================
# Visualization 1: images
# =========================
fig, axes = plt.subplots(2, len(lambd_list), figsize=(24, 8))
fig.suptitle("Smooth Transformation under CV-based Bounds", y=0.98, fontsize=30)

for j, lambd in enumerate(lambd_list):
    ax1 = axes[0, j]
    ax1.imshow(baseline_results[j], cmap='gray')
    ax1.set_title(rf"$\lambda={lambd:.1f}$", pad=10)
    ax1.axis("off")

    ax2 = axes[1, j]
    ax2.imshow(dbot_results[j], cmap='gray')
    ax2.set_title(rf"$\lambda={lambd:.1f}$", pad=10)
    ax2.axis("off")

fig.text(0.04, 0.68, "Vanilla OT", rotation=90,
         va='center', ha='center', fontsize=24)
fig.text(0.04, 0.27, "DBOT", rotation=90,
         va='center', ha='center', fontsize=24)

plt.tight_layout(rect=[0.06, 0.03, 1, 0.94])
plt.show()

# =========================
# Visualization 2: Distance curve
# =========================
x = np.array(lambd_list, dtype=np.float64)
y_base = np.array(baseline_distances, dtype=np.float64)
y_dbot = np.array(dbot_distances, dtype=np.float64)

x_smooth = np.linspace(x.min(), x.max(), 300)

if len(x) >= 4:
    cs_base = CubicSpline(x, y_base)
    cs_dbot = CubicSpline(x, y_dbot)
    y_base_smooth = cs_base(x_smooth)
    y_dbot_smooth = cs_dbot(x_smooth)
else:
    y_base_smooth = np.interp(x_smooth, x, y_base)
    y_dbot_smooth = np.interp(x_smooth, x, y_dbot)

plt.figure(figsize=(12, 8))

plt.plot(
    x_smooth, y_base_smooth,
    color='olivedrab',
    linewidth=3.0,
    label='Baseline cubic spline'
)
plt.plot(
    x, y_base,
    linestyle='None',
    marker='^',
    markersize=10,
    markerfacecolor='none',
    markeredgecolor='orange',
    markeredgewidth=2.2,
    label='Baseline points'
)

plt.plot(
    x_smooth, y_dbot_smooth,
    color='pink',
    linewidth=3.0,
    label='DBOT cubic spline'
)
plt.plot(
    x, y_dbot,
    linestyle='None',
    marker='s',
    markersize=9,
    markerfacecolor='none',
    markeredgecolor='crimson',
    markeredgewidth=2.2,
    label='DBOT points'
)

plt.title("Distance Comparison between Baseline and DBOT", pad=18)
plt.xlabel(r"$\lambda$")
plt.ylabel("Distance")
plt.xticks(lambd_list)
plt.grid(True, linestyle='--', alpha=0.4)
plt.legend(loc='best', frameon=True)
plt.tight_layout()
plt.show()
